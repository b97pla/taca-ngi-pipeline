./ANALYSIS/MH-0336/piper_ngi/06_final_alignment_qc/berF-b2-e2-l2.clean.dedup.recal.qc/css/searchtools.js
