./ANALYSIS/MH-0336/piper_ngi/02_preliminary_alignment_qc/berF-b2-e2-l2.AH009KCCXX.berF-b2-e2-l2.8.qc/css/doctools.js
