./ANALYSIS/MH-0336/piper_ngi/02_preliminary_alignment_qc/44-e1-l4.AH009KCCXX.44-e1-l4.8.qc/css/searchtools.js
